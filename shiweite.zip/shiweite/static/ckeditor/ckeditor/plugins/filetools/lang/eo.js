﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("filetools","eo",{loadError:"Eraro okazis dum la dosiera legado.",networkError:"Reta eraro okazis dum la dosiera alŝuto.",httpError404:"HTTP eraro okazis dum la dosiera alŝuto (404: dosiero ne trovita).",httpError403:"HTTP eraro okazis dum la dosiera alŝuto (403: malpermesita).",httpError:"HTTP eraro okazis dum la dosiera alŝuto (erara stato: %1).",noUrlError:"Alŝuta URL ne estas difinita.",responseError:"Malĝusta respondo de la servilo."});