"""
# -*- coding: utf-8 -*-
-------------------------------------------------
# @Project  :shiweite
# @File     :urls.py
# @Date     :2021/10/12 20:17
# @Author   :turbo
# @Email    :2647387166
# @Software :PyCharm
-------------------------------------------------
"""
from errors.views import *

handler404 = page_not_found404
handler500 = page_not_found500
urlpatterns=[]