from django.apps import AppConfig


class ErrorsConfig(AppConfig):
    name = 'errors'
